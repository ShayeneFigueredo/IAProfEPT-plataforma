/* global React, Icon, Btn, Badge, Select, TextField, ValidationNote, BiasNote, MD, Thinking, runAI,
   LAB_TOOLS, AREAS_MAT, NIVEIS, EIXOS, CURSOS_TEC, TONS, PUBLICOS, METODOLOGIAS, QTD_QUESTOES */
const { useState } = React;

// ---- Hidden, high-performance System Prompts (the "engenharia de prompts" the prof never sees) ----
const SYS = {
  base: `Você é um especialista em Educação Matemática Crítica e em Educação Profissional e Tecnológica (EPT) no Brasil. Produza conteúdo rigoroso, com precisão matemática absoluta (temperatura baixa, sem alucinações), alinhado à BNCC e a uma pedagogia crítica que valoriza a autonomia docente e a contextualização ao mundo do trabalho. Seja conciso, organizado e diretamente utilizável em sala. IMPORTANTE: não use LaTeX nem notação delimitada por $ ou $$. Escreva todas as expressões matemáticas em texto simples e legível, usando símbolos comuns (^, ÷, ×, √, ≤, ≥, π) e frações no formato a/b.`,
  exercicios: `Gere uma lista de exercícios de Matemática com gabarito comentado. Para CADA questão indique explicitamente a competência e a(s) habilidade(s) da BNCC trabalhadas (use códigos quando possível, ex.: EM13MAT...). Garanta correção matemática total e progressão de dificuldade coerente com o nível solicitado.`,
  interdisciplinar: `Crie uma atividade interdisciplinar que integre Matemática ao eixo integrador da EPT e ao curso técnico informados, a partir de um contexto REAL e autêntico do mundo do trabalho daquele curso. Explicite os objetivos de aprendizagem, a conexão interdisciplinar e as habilidades da BNCC.`,
  podcast: `Escreva um roteiro de podcast educacional sobre o tema de Matemática informado, adequado ao público e ao tom de linguagem. Estruture em blocos (abertura, desenvolvimento, encerramento) com falas, deixas e sugestões de trilha/efeitos.`,
  plano: `Elabore um plano de aula completo de Matemática com base na metodologia ativa informada. Inclua: objetivos, habilidades da BNCC, recursos, sequência didática por etapas com tempos, avaliação e proposta de contextualização para a EPT.`,
};

// ---- Realistic fallback samples (used if the live API is unavailable) ----
const FALLBACK = {
  exercicios: `### Lista de Exercícios — Funções afins · Nível Intermediário
**Curso técnico de referência:** Enfermagem

**Questão 1.** A vazão de um soro é regulada para 20 gotas por minuto. A função g(t) = 20t fornece o número de gotas em t minutos.
a) Quantas gotas caem em 15 minutos?
b) Após quanto tempo terão caído 900 gotas?
- **BNCC:** EM13MAT302 — interpretar e construir modelos de fenômenos por funções afins.

**Questão 2.** Um frasco de 500 mL é infundido a uma taxa constante de 25 mL por hora. Escreva a função do volume restante V(t).
- **BNCC:** EM13MAT401 — converter representações algébricas e gráficas de funções.

**Questão 3.** Esboce o gráfico de V(t) e identifique o instante em que o frasco se esvazia.
- **BNCC:** EM13MAT403 — analisar funções a partir de seus gráficos.

---
### Gabarito comentado
1. a) 300 gotas. b) 45 minutos (900 ÷ 20).
2. V(t) = 500 − 25t, com 0 ≤ t ≤ 20.
3. Reta decrescente; V(t) = 0 em t = 20 h.`,
  interdisciplinar: `### Atividade Interdisciplinar — Geometria espacial × Agropecuária
**Eixo integrador:** Tecnologia

**Contexto real:** A cooperativa local precisa dimensionar um **silo cilíndrico** para armazenar a safra de milho. A equipe técnica recebeu o diâmetro da base e a altura disponível no galpão.

**Desafio:** Calcular o volume útil do silo, estimar a capacidade em sacas (60 kg) e propor a altura ideal para aproveitar o espaço sem desperdício.

**Conexões interdisciplinares**
- *Matemática:* volume do cilindro, conversão de unidades, otimização.
- *Curso técnico (Agropecuária):* densidade de grãos, perdas pós-colheita, logística de armazenagem.

**Habilidades BNCC:** EM13MAT309, EM13MAT509 — resolver problemas com sólidos geométricos e modelar situações reais.

**Produto esperado:** memorial de cálculo + recomendação técnica para a cooperativa.`,
  podcast: `### Roteiro de Podcast — "Matemática que se vê no trabalho"
**Tema:** Progressões e juros · **Público:** Estudantes do médio integrado · **Tom:** Descontraído

**[ABERTURA · 0:00–1:00]**
🎵 *Vinheta animada.*
**Host:** "E aí, pessoal! Já parou pra pensar que aquele 'parcelado sem juros' quase nunca é sem juros de verdade? Hoje a Matemática vai abrir o jogo!"

**[DESENVOLVIMENTO · 1:00–7:00]**
- Bloco 1: O que é uma progressão geométrica (exemplo do boato que se espalha).
- Bloco 2: Juros compostos como PG — simulação de uma compra no cartão.
- Deixa para convidado(a): relato de uma situação real de consumo.

**[ENCERRAMENTO · 7:00–8:00]**
**Host:** "Fica a missão: calcule o juro real da sua próxima compra parcelada e me conta!"
🎵 *Encerramento.*`,
  plano: `### Plano de Aula — Estatística · Aprendizagem baseada em problemas
**Turma:** 2º ano · Téc. em Enfermagem · **Carga horária:** 2 aulas (100 min)

**Objetivos**
- Coletar, organizar e interpretar dados em situação de saúde coletiva.
- Calcular e comparar média, mediana e moda.

**Habilidades BNCC:** EM13MAT406, EM13MAT511.

**Sequência didática**
1. *Problematização (15 min):* apresentar dados reais de uma campanha de vacinação.
2. *Investigação em grupos (40 min):* organizar os dados em tabelas e gráficos.
3. *Sistematização (30 min):* cálculo das medidas e discussão de qual representa melhor o cenário.
4. *Socialização (15 min):* cada grupo defende sua conclusão.

**Recursos:** planilha, dados reais da secretaria de saúde, projetor.
**Avaliação:** rubrica de argumentação + relatório do grupo.`,
};

const BIAS = {
  exercicios: 'Verifique cada cálculo e gabarito: modelos de IA podem cometer erros aritméticos sutis e propor contextos com estereótipos. Adapte os dados à realidade da sua turma.',
  interdisciplinar: 'O contexto técnico pode conter imprecisões da área profissional. Valide os dados com um(a) docente do curso técnico antes de aplicar.',
  podcast: 'Revise informações factuais citadas no roteiro e a adequação da linguagem ao seu público real.',
  plano: 'Tempos e metodologias são sugestões. Ajuste à carga horária real, ao perfil da turma e às condições da sua escola.',
};

function LabForm({ tool, onGenerate, loading }) {
  const [f, setF] = useState({});
  const set = (k) => (v) => setF((s) => ({ ...s, [k]: v }));
  const filled = (keys) => keys.every((k) => f[k]);

  let fields, required, summary;
  if (tool === 'exercicios') {
    required = ['area', 'nivel', 'qtd', 'curso'];
    fields = (<>
      <div className="grid g2">
        <Select label="Área matemática" req placeholder="Selecione a área" value={f.area || ''} onChange={set('area')} options={AREAS_MAT} />
        <Select label="Nível de dificuldade" req placeholder="Selecione o nível" value={f.nivel || ''} onChange={set('nivel')} options={NIVEIS} />
        <Select label="Quantidade" req placeholder="Quantas questões" value={f.qtd || ''} onChange={set('qtd')} options={QTD_QUESTOES} />
        <Select label="Curso técnico (contexto)" req placeholder="Selecione o curso" value={f.curso || ''} onChange={set('curso')} options={CURSOS_TEC} />
      </div>
    </>);
    summary = `Área: ${f.area} · Nível: ${f.nivel} · ${f.qtd} · Contexto: ${f.curso}`;
  } else if (tool === 'interdisciplinar') {
    required = ['eixo', 'curso', 'area'];
    fields = (<>
      <div className="grid g2">
        <Select label="Eixo integrador da EPT" req placeholder="Selecione o eixo" value={f.eixo || ''} onChange={set('eixo')} options={EIXOS} />
        <Select label="Curso técnico" req placeholder="Selecione o curso" value={f.curso || ''} onChange={set('curso')} options={CURSOS_TEC} />
        <Select label="Área matemática" req placeholder="Selecione a área" value={f.area || ''} onChange={set('area')} options={AREAS_MAT} />
        <Select label="Nível" placeholder="Opcional" value={f.nivel || ''} onChange={set('nivel')} options={NIVEIS} />
      </div>
    </>);
    summary = `${f.area} integrada a ${f.curso} · eixo ${f.eixo}`;
  } else if (tool === 'podcast') {
    required = ['tema', 'publico', 'tom'];
    fields = (<>
      <TextField label="Tema do episódio" req placeholder="Ex.: Progressões e juros no dia a dia" value={f.tema || ''} onChange={(e) => set('tema')(e.target.value)} />
      <div className="grid g2">
        <Select label="Público-alvo" req placeholder="Selecione o público" value={f.publico || ''} onChange={set('publico')} options={PUBLICOS} />
        <Select label="Tom de linguagem" req placeholder="Selecione o tom" value={f.tom || ''} onChange={set('tom')} options={TONS} />
      </div>
    </>);
    summary = `Tema: ${f.tema} · ${f.publico} · tom ${f.tom}`;
  } else {
    required = ['tema', 'turma', 'carga', 'metodologia'];
    fields = (<>
      <div className="grid g2">
        <TextField label="Tema da aula" req placeholder="Ex.: Funções afins" value={f.tema || ''} onChange={(e) => set('tema')(e.target.value)} />
        <TextField label="Turma / curso" req placeholder="Ex.: 2º ano · Enfermagem" value={f.turma || ''} onChange={(e) => set('turma')(e.target.value)} />
        <TextField label="Carga horária" req placeholder="Ex.: 2 aulas (100 min)" value={f.carga || ''} onChange={(e) => set('carga')(e.target.value)} />
        <Select label="Metodologia ativa" req placeholder="Selecione a metodologia" value={f.metodologia || ''} onChange={set('metodologia')} options={METODOLOGIAS} />
      </div>
    </>);
    summary = `${f.tema} · ${f.turma} · ${f.carga}`;
  }

  const ready = filled(required);
  const payload = Object.entries(f).filter(([, v]) => v).map(([k, v]) => `${k}: ${v}`).join('\n');

  return (
    <div className="card card-pad">
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 6 }}>
        <Icon.settings style={{ width: 16, height: 16, color: 'var(--ink-400)' }} />
        <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-700)' }}>Parâmetros estruturados</span>
      </div>
      <p style={{ fontSize: 13, color: 'var(--ink-500)', marginBottom: 18, lineHeight: 1.5 }}>
        Você nunca encontra uma caixa de prompt vazia. Escolha os parâmetros e o sistema monta, nos bastidores, um prompt pedagógico de alto desempenho.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>{fields}</div>

      <div style={{ marginTop: 18, display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
        <Btn icon="spark" disabled={!ready || loading} onClick={() => onGenerate({ summary, payload })}>
          {loading ? <><span className="spinner" />Gerando…</> : 'Gerar com IA'}
        </Btn>
        {!ready && <span className="help">Preencha os campos obrigatórios <span style={{ color: 'var(--red-600)' }}>*</span> para liberar a geração.</span>}
      </div>

      <details style={{ marginTop: 16 }}>
        <summary style={{ cursor: 'pointer', fontSize: 12.5, fontWeight: 700, color: 'var(--green-700)' }}>
          Ver prompt de bastidores (System Prompt oculto)
        </summary>
        <pre style={{ marginTop: 10, background: 'var(--surface-2)', borderRadius: 12, padding: 14, fontSize: 12, color: 'var(--ink-500)', whiteSpace: 'pre-wrap', lineHeight: 1.5, fontFamily: 'var(--font-ui)' }}>
{SYS.base}{'\n\n'}{SYS[tool]}{'\n\n[+ parâmetros do docente injetados automaticamente]'}
        </pre>
      </details>
    </div>
  );
}

function Laboratorio() {
  const [tool, setTool] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const t = LAB_TOOLS.find((x) => x.id === tool);

  const generate = async ({ summary, payload }) => {
    setLoading(true); setResult(null);
    const sys = `${SYS.base}\n\n${SYS[tool]}`;
    const out = await runAI(sys, payload, FALLBACK[tool]);
    setResult({ text: out, summary }); setLoading(false);
  };

  if (!tool) {
    return (
      <div className="view fade-up">
        <PageHead eyebrow="O motor da plataforma" eyebrowIcon="flask" title="Laboratório de Experimentações"
          sub="Manipule ferramentas de IA generativa aplicadas, de forma contextualizada, ao ensino de Matemática na EPT. Escolha uma ferramenta para começar." />
        <div className="grid g2" style={{ marginBottom: 28 }}>
          {LAB_TOOLS.map((x) => {
            const Ic = Icon[x.icon];
            return (
              <button key={x.id} className="card tool-card" onClick={() => { setTool(x.id); setResult(null); }}>
                <div style={{ padding: 22, display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div className="ic-wrap" style={{ background: x.tint, color: x.color }}><Ic /></div>
                  <div style={{ flex: 1 }}>
                    <h3 style={{ fontSize: 17, marginBottom: 6 }}>{x.title}</h3>
                    <p style={{ fontSize: 13.5, color: 'var(--ink-500)', lineHeight: 1.5 }}>{x.desc}</p>
                  </div>
                  <Icon.arrowRight style={{ width: 18, height: 18, color: 'var(--ink-400)' }} />
                </div>
              </button>
            );
          })}
        </div>
        <div className="ai-validation">
          <Icon.shield className="ic" />
          <div className="t"><b>Como funciona a ética aqui.</b> Toda resposta gerada exibe a nota de validação obrigatória e alertas sobre limitações e vieses. O conteúdo é um ponto de partida — a decisão pedagógica é sempre sua.</div>
        </div>
      </div>
    );
  }

  const Ic = Icon[t.icon];
  return (
    <div className="view fade-up">
      <button className="btn btn-ghost btn-sm" style={{ marginBottom: 18 }} onClick={() => { setTool(null); setResult(null); }}>
        <Icon.arrowRight style={{ transform: 'rotate(180deg)' }} /> Todas as ferramentas
      </button>
      <div className="page-head" style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
        <div className="ic-wrap" style={{ width: 52, height: 52, borderRadius: 15, background: t.tint, color: t.color, display: 'grid', placeItems: 'center' }}><Ic style={{ width: 26, height: 26 }} /></div>
        <div>
          <h1 style={{ fontSize: 28 }}>{t.title}</h1>
          <p className="sub" style={{ marginTop: 4 }}>{t.desc}</p>
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: '1fr', gap: 22 }}>
        <LabForm tool={tool} onGenerate={generate} loading={loading} />

        {loading && <div className="ai-output"><Thinking /></div>}

        {result && !loading && (
          <div className="ai-output fade-up">
            <div className="ai-output-head">
              <div className="spark"><Icon.spark /></div>
              <div style={{ flex: 1 }}>
                <h4>Conteúdo gerado</h4>
                <div className="meta">{result.summary}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Btn variant="ghost" sm icon="copy" onClick={() => navigator.clipboard && navigator.clipboard.writeText(result.text)}>Copiar</Btn>
                <Btn variant="ghost" sm icon="download">Exportar</Btn>
              </div>
            </div>
            <div className="ai-body">
              <div style={{ marginBottom: 16 }}><ValidationNote /></div>
              <MD text={result.text} />
              <div style={{ marginTop: 18 }}><BiasNote>{BIAS[tool]}</BiasNote></div>
              <div style={{ marginTop: 16, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <Btn variant="soft" sm icon="refresh" onClick={() => { /* regenerate uses last summary—simplest: rerun via form */ }}>Gerar variação</Btn>
                <Btn variant="ghost" sm icon="bookmark">Salvar no portfólio</Btn>
                <Btn variant="ghost" sm icon="upload">Enviar ao Repositório</Btn>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { Laboratorio });
