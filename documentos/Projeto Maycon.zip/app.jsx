/* global React, ReactDOM, Icon, Logo, USER, MODULES,
   Inicio, Formativo, Laboratorio, Repositorio, Reflexao, Suporte, Maicon,
   Landing, Login, Cadastro, useTweaks, TweaksPanel, TweakSection, TweakRadio */
const { useState: useA, useEffect: useAE } = React;

const TITLES = {
  inicio: 'Início', formativo: 'Ambiente Formativo', laboratorio: 'Laboratório de IA',
  repositorio: 'Repositório', reflexao: 'Reflexão Crítica', suporte: 'Suporte',
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "headingFont": "Space Grotesk",
  "radius": "Padrão",
  "density": "Padrão"
}/*EDITMODE-END*/;

const RADIUS_MAP = {
  'Suave':       { sm: '7px',  md: '9px',  lg: '12px', xl: '18px' },
  'Padrão':      { sm: '10px', md: '14px', lg: '20px', xl: '28px' },
  'Arredondado': { sm: '14px', md: '18px', lg: '26px', xl: '34px' },
};
const DENSITY_MAP = {
  'Compacta': { view: '22px', card: '16px' },
  'Padrão':   { view: '32px', card: '22px' },
  'Espaçosa': { view: '44px', card: '28px' },
};

function App() {
  const [phase, setPhase] = useA('landing'); // 'landing' | 'login' | 'app'
  const [route, setRoute] = useA('inicio');
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const go = (r) => { setRoute(r); window.scrollTo({ top: 0 }); };

  useAE(() => {
    const root = document.documentElement.style;
    root.setProperty('--font-display', `'${t.headingFont}', sans-serif`);
    const r = RADIUS_MAP[t.radius] || RADIUS_MAP['Padrão'];
    root.setProperty('--r-sm', r.sm); root.setProperty('--r-md', r.md);
    root.setProperty('--r-lg', r.lg); root.setProperty('--r-xl', r.xl);
    const d = DENSITY_MAP[t.density] || DENSITY_MAP['Padrão'];
    root.setProperty('--view-pad', d.view); root.setProperty('--card-pad', d.card);
  }, [t.headingFont, t.radius, t.density]);

  const groups = [
    { label: null, items: MODULES.filter((m) => m.group === 0) },
    { label: 'Ambientes', items: MODULES.filter((m) => m.group === 1) },
  ];

  if (phase === 'landing') return <Landing onEnter={() => { setPhase('login'); window.scrollTo({ top: 0 }); }} />;
  if (phase === 'login') return <Login onSuccess={() => { setPhase('app'); go('inicio'); }} onBack={() => { setPhase('landing'); window.scrollTo({ top: 0 }); }} onCadastro={() => { setPhase('cadastro'); window.scrollTo({ top: 0 }); }} />;
  if (phase === 'cadastro') return <Cadastro onSuccess={() => { setPhase('app'); go('inicio'); }} onLogin={() => { setPhase('login'); window.scrollTo({ top: 0 }); }} onBack={() => { setPhase('landing'); window.scrollTo({ top: 0 }); }} />;

  let View;
  if (route === 'inicio') View = <Inicio go={go} />;
  else if (route === 'formativo') View = <Formativo />;
  else if (route === 'laboratorio') View = <Laboratorio />;
  else if (route === 'repositorio') View = <Repositorio />;
  else if (route === 'reflexao') View = <Reflexao />;
  else View = <Suporte />;

  return (
    <div className="app">
      <aside className="sidebar">
        <Logo size={32} />
        <nav className="nav">
          {groups.map((g, gi) => (
            <React.Fragment key={gi}>
              {g.label && <div className="nav-label">{g.label}</div>}
              {g.items.map((m) => {
                const Ic = Icon[m.icon];
                return (
                  <button key={m.id} className={`nav-item${route === m.id ? ' active' : ''}`} onClick={() => go(m.id)}>
                    <Ic /><span>{m.label}</span>
                    {m.badge && <span className="nav-badge">{m.badge}</span>}
                  </button>
                );
              })}
            </React.Fragment>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="user-card">
            <div className="avatar">{USER.initials}</div>
            <div className="u-meta">
              <div className="u-name">{USER.name}</div>
              <div className="u-role">{USER.role}</div>
            </div>
          </div>
          <button className="btn-sair" onClick={() => { setPhase('landing'); window.scrollTo({ top: 0 }); }}><Icon.logout /><span>Sair</span></button>
        </div>
      </aside>

      <div className="main">
        <header className="topbar">
          <div className="crumb">IAprofEPT <span style={{ margin: '0 6px' }}>/</span> <b>{TITLES[route]}</b></div>
          <div className="search"><Icon.search /><input placeholder="Buscar na plataforma…" /></div>
          <button className="icon-btn"><Icon.bell /><span className="dot" /></button>
        </header>
        {View}
      </div>

      <Maicon />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Tipografia" />
        <TweakRadio label="Fonte dos títulos" value={t.headingFont}
          options={['Space Grotesk', 'Sora', 'Plus Jakarta Sans']}
          onChange={(v) => setTweak('headingFont', v)} />
        <TweakSection label="Forma & ritmo" />
        <TweakRadio label="Cantos" value={t.radius}
          options={['Suave', 'Padrão', 'Arredondado']}
          onChange={(v) => setTweak('radius', v)} />
        <TweakRadio label="Densidade" value={t.density}
          options={['Compacta', 'Padrão', 'Espaçosa']}
          onChange={(v) => setTweak('density', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
