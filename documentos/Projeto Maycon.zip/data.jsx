/* global window */
// ============ Static data for the prototype ============

const USER = { name: 'Prof. Maycon Magalhães', role: 'Docente de Matemática · IFNMG', initials: 'M' };

const MODULES = [
  { id: 'inicio', label: 'Início', icon: 'home', group: 0 },
  { id: 'formativo', label: 'Ambiente Formativo', icon: 'book', group: 1, badge: '4' },
  { id: 'laboratorio', label: 'Laboratório de IA', icon: 'flask', group: 1 },
  { id: 'repositorio', label: 'Repositório', icon: 'repo', group: 1 },
  { id: 'reflexao', label: 'Reflexão Crítica', icon: 'scale', group: 1 },
  { id: 'suporte', label: 'Suporte', icon: 'help', group: 1 },
];

const AMBIENTES = [
  { id: 'formativo', icon: 'book', title: 'Ambiente Formativo', desc: 'Trilhas de formação continuada, materiais orientadores e e-book de prompts.', tint: 'var(--green-50)', color: 'var(--green-700)' },
  { id: 'laboratorio', icon: 'flask', title: 'Laboratório de IA', desc: 'O motor da plataforma: gere exercícios, planos e atividades com IA generativa contextualizada.', tint: '#eaf3ff', color: '#1e5fb0' },
  { id: 'repositorio', icon: 'repo', title: 'Repositório de Práticas', desc: 'Curadoria colaborativa de sequências didáticas, com filtros e exportação.', tint: 'var(--amber-100)', color: '#9a5a16' },
  { id: 'reflexao', icon: 'scale', title: 'Reflexão Crítica', desc: 'Fóruns, artigos e provocações sobre ética e uso crítico da IA na docência.', tint: 'var(--red-50)', color: 'var(--red-600)' },
  { id: 'suporte', icon: 'help', title: 'Acompanhamento e Suporte', desc: 'Tutoriais, reporte de erros e seu portfólio formativo de engajamento.', tint: '#f0eefb', color: '#6b51c4' },
];

// ---- Ambiente Formativo ----
const TRILHA = [
  { n: 1, title: 'Fundamentos da Inteligência Artificial', desc: 'O que é IA, machine learning e IA generativa — conceitos essenciais para o docente.', lessons: 6, mins: 48, progress: 100, status: 'done' },
  { n: 2, title: 'Ética no Uso de IA na Educação', desc: 'Vieses, privacidade, autoria e os limites éticos do uso de IA em sala de aula.', lessons: 5, mins: 52, progress: 60, status: 'now' },
  { n: 3, title: 'Possibilidades Didáticas com Ferramentas Generativas', desc: 'Estratégias práticas de uso de IA Gen no ensino de Matemática na EPT.', lessons: 7, mins: 64, progress: 0, status: 'lock' },
  { n: 4, title: 'Estudos de Caso sobre o Uso de IA na EPT', desc: 'Casos reais comentados de integração entre Matemática, IA e cursos técnicos.', lessons: 4, mins: 40, progress: 0, status: 'lock' },
];

const DOCS = [
  { t: 'Recomendação da UNESCO sobre Ética da IA', tag: 'Documento', kind: 'doc' },
  { t: 'Plano Brasileiro de Inteligência Artificial (PBIA)', tag: 'Legislação', kind: 'doc' },
  { t: 'Guia: IA Generativa na Educação Básica e Profissional', tag: 'Guia', kind: 'doc' },
  { t: 'Vídeo · IA crítica na Educação Matemática', tag: 'YouTube', kind: 'video' },
  { t: 'Artigo · Educação Matemática Crítica e tecnologias', tag: 'Artigo', kind: 'doc' },
];

// Vídeos (aulas, palestras e lives) — embed do YouTube
const VIDEOS = [
  { id: 'Q_2bAN04KF0', titulo: 'IA na Educação Matemática da EPT — Live de abertura', autor: 'Prof. Maycon Magalhães', dur: 'Live', tag: 'Palestra', desc: 'Discussão de abertura sobre o uso crítico e ético da Inteligência Artificial no ensino de Matemática na Educação Profissional e Tecnológica.' },
];

const PROMPTS_EBOOK = [
  { titulo: 'Diagnóstico de pré-requisitos', texto: 'Liste os pré-requisitos matemáticos essenciais para ensinar [TEMA] a uma turma de [CURSO TÉCNICO], com 3 perguntas diagnósticas de sondagem para cada pré-requisito.', tag: 'Diagnóstico' },
  { titulo: 'Contextualização técnica', texto: 'Reescreva o problema matemático "[PROBLEMA]" em um contexto autêntico do curso técnico de [CURSO], preservando o mesmo objetivo de aprendizagem e indicando a habilidade da BNCC trabalhada.', tag: 'Contextualização' },
  { titulo: 'Erro produtivo', texto: 'Crie 3 resoluções de [TEMA] contendo erros conceituais comuns e proponha perguntas que levem os estudantes a identificar e corrigir cada erro.', tag: 'Avaliação formativa' },
  { titulo: 'Feedback devolutivo', texto: 'Gere um modelo de feedback devolutivo, em linguagem acolhedora, para um estudante que apresentou a seguinte dificuldade em [TEMA]: [DIFICULDADE].', tag: 'Feedback' },
];

const IA_INDICACOES = [
  { nome: 'Assistentes de texto (GPT/Claude)', uso: 'Planejamento, geração de enunciados e devolutivas. Sempre revisar o conteúdo matemático.' },
  { nome: 'NotebookLM', uso: 'Leitura e síntese de documentos longos (legislações, artigos) com citação das fontes.' },
  { nome: 'Geradores de imagem', uso: 'Criar representações visuais e infográficos para conceitos abstratos.' },
];

// ---- Repositório ----
const PRATICAS = [
  { titulo: 'Funções afins na dosagem de medicamentos', autor: 'Prof. Maycon', curso: 'Enfermagem', tema: 'Funções', tipo: 'Sequência didática', likes: 24, files: 2, dias: 3 },
  { titulo: 'Progressões e cálculo de juros no comércio', autor: 'Prof. Renato', curso: 'Administração', tema: 'Progressões', tipo: 'Plano de aula', likes: 18, files: 1, dias: 8 },
  { titulo: 'Geometria espacial no projeto de silos', autor: 'Prof. Aline', curso: 'Agropecuária', tema: 'Geometria', tipo: 'Projeto integrador', likes: 31, files: 3, dias: 12 },
  { titulo: 'Lógica e funções no pensamento computacional', autor: 'Prof. Diego', curso: 'Informática', tema: 'Lógica', tipo: 'Sequência didática', likes: 27, files: 2, dias: 15 },
  { titulo: 'Estatística aplicada a indicadores de saúde', autor: 'Profa. Carla', curso: 'Enfermagem', tema: 'Estatística', tipo: 'Atividade', likes: 14, files: 1, dias: 21 },
  { titulo: 'Trigonometria em topografia rural', autor: 'Prof. Aline', curso: 'Agropecuária', tema: 'Trigonometria', tipo: 'Plano de aula', likes: 9, files: 2, dias: 26 },
];

const CURSOS_FILTRO = ['Todos', 'Informática', 'Agropecuária', 'Enfermagem', 'Administração'];

// ---- Reflexão Crítica ----
const FORUNS = [
  { titulo: 'Até onde a IA pode "corrigir" provas sem desumanizar a avaliação?', autor: 'Prof. Diego', respostas: 14, ativo: true, tag: 'Avaliação' },
  { titulo: 'Vieses algorítmicos: como percebê-los em enunciados gerados?', autor: 'Profa. Carla', respostas: 9, ativo: true, tag: 'Vieses' },
  { titulo: 'Autoria docente x conteúdo gerado: de quem é o plano de aula?', autor: 'Prof. Renato', respostas: 21, ativo: false, tag: 'Autoria' },
];

const PROVOCACOES = [
  'Se a IA gera o exercício, qual passa a ser o papel insubstituível do professor de Matemática?',
  'Usar IA economiza tempo — mas o que fazemos com o tempo que ela nos devolve?',
  'Um enunciado "neutro" existe? Quem é representado nos contextos que a IA cria?',
];

const ARTIGOS = [
  { t: 'A docência na era da automação: resistência ou reinvenção?', autor: 'Entrevista · Profa. Iasmim', tag: 'Entrevista' },
  { t: 'Educação Matemática Crítica e o uso responsável de algoritmos', autor: 'Artigo de opinião', tag: 'Opinião' },
];

// ---- Suporte / indicadores ----
const INDICADORES = [
  { n: '2 / 4', l: 'Trilhas em andamento', icon: 'graph', tint: 'var(--green-50)', color: 'var(--green-700)' },
  { n: '17', l: 'Materiais gerados na IA', icon: 'spark', tint: '#eaf3ff', color: '#1e5fb0' },
  { n: '3', l: 'Práticas compartilhadas', icon: 'repo', tint: 'var(--amber-100)', color: '#9a5a16' },
  { n: '8', l: 'Posts no fórum', icon: 'chat', tint: '#f0eefb', color: '#6b51c4' },
];

const TUTORIAIS = [
  { t: 'Primeiros passos na plataforma', mins: 4 },
  { t: 'Como gerar exercícios alinhados à BNCC', mins: 6 },
  { t: 'Compartilhando uma prática no Repositório', mins: 3 },
  { t: 'Usando o assistente Prof. mAIcon', mins: 2 },
];

// ---- Laboratório: ferramentas e opções ----
const LAB_TOOLS = [
  { id: 'exercicios', icon: 'calc', title: 'Exercícios e Avaliações', desc: 'Gera questões com gabarito automático e habilidades da BNCC.', tint: 'var(--green-50)', color: 'var(--green-700)' },
  { id: 'interdisciplinar', icon: 'layers', title: 'Atividades Interdisciplinares', desc: 'Integra Matemática ao eixo da EPT e ao curso técnico.', tint: '#eaf3ff', color: '#1e5fb0' },
  { id: 'podcast', icon: 'podcast', title: 'Roteiros de Podcast', desc: 'Roteiros educativos com tema, público e tom de linguagem.', tint: 'var(--amber-100)', color: '#9a5a16' },
  { id: 'plano', icon: 'doc', title: 'Planejamento de Aulas', desc: 'Planos com metodologias ativas a partir de tema e carga horária.', tint: '#f0eefb', color: '#6b51c4' },
];

const AREAS_MAT = ['Aritmética e operações', 'Funções', 'Progressões (PA/PG)', 'Geometria plana', 'Geometria espacial', 'Trigonometria', 'Estatística', 'Probabilidade', 'Matemática financeira', 'Análise combinatória'];
const NIVEIS = ['Inicial', 'Intermediário', 'Avançado'];
const EIXOS = ['Trabalho', 'Ciência', 'Tecnologia', 'Cultura'];
const CURSOS_TEC = ['Informática', 'Agropecuária', 'Enfermagem', 'Administração', 'Edificações', 'Eletrotécnica', 'Química'];
const TONS = ['Formal', 'Descontraído'];
const PUBLICOS = ['Estudantes do ensino médio integrado', 'Docentes em formação', 'Público geral'];
const METODOLOGIAS = ['Aprendizagem baseada em problemas', 'Sala de aula invertida', 'Aprendizagem por projetos', 'Gamificação', 'Ensino híbrido'];
const QTD_QUESTOES = ['3 questões', '5 questões', '10 questões'];

// Mandatory validation note (literal, per the spec)
const VALIDATION_NOTE = 'Este conteúdo foi gerado por Inteligência Artificial. Cabe ao professor revisar, adaptar e validar pedagogicamente sua aplicação.';

const NOTEBOOK_TEXT = 'Clique aqui para acessar o NotebookLM: uma ferramenta da Google baseada em IA para leitura e interpretação de documentos. Você poderá fazer upload de PDFs, perguntas e pedir resumos. Use com responsabilidade, sempre analisando criticamente as respostas da IA.';

Object.assign(window, {
  USER, MODULES, AMBIENTES, TRILHA, DOCS, VIDEOS, PROMPTS_EBOOK, IA_INDICACOES,
  PRATICAS, CURSOS_FILTRO, FORUNS, PROVOCACOES, ARTIGOS, INDICADORES, TUTORIAIS,
  LAB_TOOLS, AREAS_MAT, NIVEIS, EIXOS, CURSOS_TEC, TONS, PUBLICOS, METODOLOGIAS,
  QTD_QUESTOES, VALIDATION_NOTE, NOTEBOOK_TEXT,
});
