/* global React, Icon, Logo, Btn, AMBIENTES, MaiconFace */
const { useState: useE } = React;

// ============ Landing nav ============
function LandingNav({ onEnter }) {
  return (
    <nav className="lnav">
      <Logo size={32} dark />
      <div className="lnav-links">
        <a href="#ambientes">Ambientes</a>
        <a href="#principios">Como funciona</a>
        <a href="#etica">Ética</a>
      </div>
      <div className="lnav-cta">
        <button className="btn btn-primary" onClick={onEnter}><Icon.logout style={{ transform: 'scaleX(-1)' }} /> Entrar</button>
      </div>
    </nav>);

}

// ============ Hero product preview ============
function HeroPreview() {
  return (
    <div className="h-visual">
      <div className="float-badge fb-bncc"><Icon.target /> Alinhado à BNCC</div>
      <div className="preview">
        <div className="pv-top"><i /><i /><i /><span className="pv-ttl">Laboratório de IA · Exercícios</span></div>
        <div className="pv-body">
          <div className="pv-head">
            <div className="pv-ic"><Icon.calc /></div>
            <div><b>Exercícios e Avaliações</b><span>Parâmetros estruturados — sem prompt vazio</span></div>
          </div>
          <div className="pv-row">
            <div className="pv-pill"><span>Área</span><b>Funções</b></div>
            <div className="pv-pill"><span>Nível</span><b>Intermediário</b></div>
            <div className="pv-pill"><span>Curso</span><b>Matemática</b></div>
            <div className="pv-pill"><span>Questões</span><b>3</b></div>
          </div>
          <div className="pv-gen"><Icon.spark /> Gerar com IA</div>
          <div className="pv-out">
            <div className="pv-valid"><Icon.shield /> Conteúdo gerado por IA — revise e valide</div>
            <div className="pv-lines">
              <i style={{ width: '88%' }} /><i style={{ width: '96%' }} /><i style={{ width: '70%' }} /><i style={{ width: '82%' }} />
            </div>
          </div>
        </div>
      </div>
      <div className="float-badge fb-maicon"><span className="mface"><MaiconFace size={26} /></span> Prof. mAIcon online</div>
    </div>);

}

// ============ Landing ============
function Landing({ onEnter }) {
  const PRINC = [
  { ic: 'briefcase', h: 'Contextualização à EPT', p: 'Cada conteúdo é ancorado no eixo integrador e no curso técnico — Matemática que conversa com o mundo do trabalho.' },
  { ic: 'settings', h: 'Engenharia de prompts oculta', p: 'O professor nunca encara uma caixa de prompt vazia. Você escolhe os parâmetros e a plataforma monta um prompt pedagógico de alto desempenho.' },
  { ic: 'shield', h: 'Validação pedagógica', p: 'Toda resposta vem com a nota de validação obrigatória e alertas de viés. A decisão pedagógica permanece, sempre, com você.' }];

  return (
    <div className="landing">
      <LandingNav onEnter={onEnter} />

      <header className="hero">
        <div className="h-copy">
          <div className="h-eyebrow"><Icon.spark /> Ambiente virtual de apoio à docência</div>
          <h1><span className="accent">Inteligência Artificial</span> na Educação Profissional e Tecnológica</h1>
          <p className="h-sub">Plataforma de apoio à prática docente de Matemática, voltada à experimentação e à reflexão crítica sobre o uso da IA na educação.</p>
          <div className="h-cta">
            <button className="btn btn-primary" onClick={onEnter}>Comece agora <Icon.arrowRight /></button>
            <a className="btn btn-ghost" href="#ambientes">Conhecer os ambientes</a>
          </div>
          <div className="h-trust">
            <div className="t-item"><Icon.checkCircle /> 5 ambientes integrados</div>
            <span className="sep" />
            <div className="t-item"><Icon.checkCircle /> IA contextualizada à Matemática</div>
            <span className="sep" />
            <div className="t-item"><Icon.checkCircle /> Uso ético em destaque</div>
          </div>
        </div>
        <HeroPreview />
      </header>

      {/* Ambientes */}
      <section className="lsection" id="ambientes">
        <div className="lsection-head">
          <div className="eyebrow"><Icon.layers /> Arquitetura da plataforma</div>
          <h2>Os 5 ambientes da plataforma</h2>
          <p>Macro-áreas interligadas que cobrem da formação continuada à experimentação prática e à reflexão crítica.</p>
        </div>
        <div className="amb-grid">
          {AMBIENTES.map((a, i) => {
            const Ic = Icon[a.icon];
            return (
              <button key={a.id} className="amb-show" onClick={onEnter}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div className="ic" style={{ background: a.tint, color: a.color }}><Ic /></div>
                  <span className="num">0{i + 1}</span>
                </div>
                <h3>{a.title}</h3>
                <p>{a.desc}</p>
              </button>);

          })}
          <div className="amb-show" style={{ background: 'var(--green-800)', backgroundImage: 'linear-gradient(150deg,#0a6b51,#064E3B)', color: '#fff', cursor: 'default', justifyContent: 'center' }}>
            <h3 style={{ color: '#fff', fontSize: 21 }}>Tudo em um só lugar.</h3>
            <p style={{ color: 'rgba(234,250,243,.8)' }}>Entre na plataforma e comece a experimentar agora mesmo.</p>
            <button className="btn" style={{ background: '#fff', color: 'var(--green-800)', marginTop: 6, width: 'fit-content' }} onClick={onEnter}>Entrar <Icon.arrowRight /></button>
          </div>
        </div>
      </section>

      {/* Princípios */}
      <section className="lsection" id="principios">
        <div className="lsection-head">
          <div className="eyebrow"><Icon.bulb /> Princípios de design</div>
          <h2>Pensada para o professor — não para substituí-lo</h2>
        </div>
        <div className="principles">
          {PRINC.map((p, i) => {
            const Ic = Icon[p.ic];
            return (
              <div key={i} className="principle">
                <div className="p-ic"><Ic /></div>
                <h3>{p.h}</h3>
                <p>{p.p}</p>
              </div>);

          })}
        </div>
      </section>

      {/* Ética band */}
      <section className="ethics-band" id="etica">
        <div className="ethics-inner">
          <div className="e-ic"><Icon.shield /></div>
          <div>
            <div className="e-tag"><span className="reddot" /> Compromisso ético</div>
            <blockquote>“Este conteúdo foi gerado por Inteligência Artificial. Cabe ao professor revisar, adaptar e validar pedagogicamente sua aplicação.”</blockquote>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="lfooter">
        <div className="lfooter-inner">
          <div className="lfooter-top">
            <div>
              <Logo size={34} />
              <p className="f-about">Ambiente virtual de apoio à docência em Matemática na Educação Profissional e Tecnológica. Produto Educacional vinculado ao programa de Pós-Graduação.</p>
            </div>
            <div style={{ padding: "0px", lineHeight: "1.9", margin: "0px" }}>
              <h4>Plataforma</h4>
              <a href="#ambientes">Ambientes</a>
              <a href="#principios">Como funciona</a>
              <a href="#etica">Ética e IA</a>
            </div>
            <div>
              <h4>Institucional</h4>
              <a href="#">IFNMG</a>
              <a href="https://notebooklm.google.com/" target="_blank" rel="noreferrer">NotebookLM</a>
              <a href="#">Contato e suporte</a>
            </div>
          </div>
          <div className="lfooter-bottom">
            <span>© 2026      IAprofEPT · Prof. Maycon Magalhães</span>
            <span>Feito para a docência crítica em Matemática</span>
          </div>
        </div>
      </footer>
    </div>);

}

// ============ Login ============
function Login({ onSuccess, onBack, onCadastro }) {
  const [email, setEmail] = useE('');
  const [pass, setPass] = useE('');
  const [show, setShow] = useE(false);
  const [remember, setRemember] = useE(true);
  const submit = (e) => {e.preventDefault();onSuccess();};

  return (
    <div className="login">
      <div className="login-brand">
        <button className="lb-back" onClick={onBack}><Icon.arrowRight style={{ transform: 'rotate(180deg)' }} /> Voltar à apresentação</button>
        <div className="lb-mid">
          <Logo size={36} />
          <h2>Bem-vindo de volta à sua sala de experimentações.</h2>
          <div className="lb-feats">
            <div className="lb-feat"><div className="f-ic"><Icon.flask /></div><div className="f-t"><b>Laboratório de IA</b><span>Gere exercícios, planos e atividades contextualizadas.</span></div></div>
            <div className="lb-feat"><div className="f-ic"><Icon.book /></div><div className="f-t"><b>Trilhas formativas</b><span>Continue de onde parou na sua formação.</span></div></div>
            <div className="lb-feat"><div className="f-ic"><Icon.shield /></div><div className="f-t"><b>Uso ético em destaque</b><span>Validação pedagógica em cada conteúdo gerado.</span></div></div>
          </div>
        </div>
        <div className="lb-maicon">
          <span className="mface"><MaiconFace size={42} /></span>
          <span>“Qualquer dúvida na navegação, é só me chamar.”<br /><b style={{ color: '#fff' }}>— Prof. mAIcon</b></span>
        </div>
      </div>

      <div className="login-form-wrap">
        <div className="login-card">
          <div className="lc-mobile-logo"><Logo size={34} dark /></div>
          <h1>Entrar na plataforma</h1>
          <p className="lc-sub">Acesse com suas credenciais de docente.</p>
          <form onSubmit={submit}>
            <div className="field">
              <label>E-mail</label>
              <input type="email" placeholder="seu.nome@ifnmg.edu.br" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="field">
              <label>Senha</label>
              <div className="lc-pass-wrap">
                <input type={show ? 'text' : 'password'} placeholder="••••••••" value={pass} onChange={(e) => setPass(e.target.value)} required />
                <button type="button" className="toggle" onClick={() => setShow(!show)} aria-label="Mostrar senha">
                  {show ? <Icon.eyeOff /> : <Icon.eye />}
                </button>
              </div>
            </div>
            <div className="lc-meta">
              <label className="lc-check"><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} /> Lembrar de mim</label>
              <a className="lc-link" href="#" onClick={(e) => e.preventDefault()}>Esqueci a senha</a>
            </div>
            <button type="submit" className="btn btn-primary btn-block" style={{ padding: 15 }}>Entrar <Icon.arrowRight /></button>
          </form>
          <p className="lc-foot">Primeiro acesso? <a href="#" onClick={(e) => {e.preventDefault(); onCadastro && onCadastro();}}>Solicite seu cadastro</a></p>
        </div>
      </div>
    </div>);

}

// ============ Cadastro (criar conta) ============
function Cadastro({ onSuccess, onLogin, onBack }) {
  const [f, setF] = useE({ nome: '', email: '', instituicao: '', campus: '', area: 'Matemática', senha: '', confirma: '' });
  const [show, setShow] = useE(false);
  const [aceite, setAceite] = useE(false);
  const set = (k) => (v) => setF((s) => ({ ...s, [k]: v }));

  const senhaForte = f.senha.length >= 6;
  const confere = f.confirma.length > 0 && f.senha === f.confirma;
  const ready = f.nome.trim() && f.email.trim() && f.instituicao.trim() && senhaForte && confere && aceite;
  const submit = (e) => { e.preventDefault(); if (ready) onSuccess(); };

  return (
    <div className="login">
      <div className="login-brand">
        <button className="lb-back" onClick={onBack}><Icon.arrowRight style={{ transform: 'rotate(180deg)' }} /> Voltar à apresentação</button>
        <div className="lb-mid">
          <Logo size={36} />
          <h2>Crie sua conta e comece a experimentar a IA na sua prática.</h2>
          <div className="lb-feats">
            <div className="lb-feat"><div className="f-ic"><Icon.users /></div><div className="f-t"><b>Comunidade docente</b><span>Compartilhe e descubra práticas no Repositório.</span></div></div>
            <div className="lb-feat"><div className="f-ic"><Icon.flask /></div><div className="f-t"><b>Laboratório de IA</b><span>Gere exercícios, planos e atividades contextualizadas.</span></div></div>
            <div className="lb-feat"><div className="f-ic"><Icon.shield /></div><div className="f-t"><b>Uso ético em destaque</b><span>Validação pedagógica em cada conteúdo gerado.</span></div></div>
          </div>
        </div>
        <div className="lb-maicon">
          <span className="mface"><MaiconFace size={42} /></span>
          <span>“Que bom ter você aqui! Vamos juntos nessa.”<br /><b style={{ color: '#fff' }}>— Prof. mAIcon</b></span>
        </div>
      </div>

      <div className="login-form-wrap">
        <div className="login-card login-card-wide">
          <div className="lc-mobile-logo"><Logo size={34} dark /></div>
          <h1>Criar conta</h1>
          <p className="lc-sub">Cadastro para docentes da Educação Profissional e Tecnológica.</p>
          <form onSubmit={submit}>
            <div className="field">
              <label>Nome completo</label>
              <input type="text" placeholder="Ex.: Maycon Magalhães" value={f.nome} onChange={(e) => set('nome')(e.target.value)} required />
            </div>
            <div className="field">
              <label>E-mail</label>
              <input type="email" placeholder="seu.nome@ifnmg.edu.br" value={f.email} onChange={(e) => set('email')(e.target.value)} required />
            </div>
            <div className="lc-grid2">
              <div className="field">
                <label>Instituição</label>
                <input type="text" placeholder="Ex.: IFNMG" value={f.instituicao} onChange={(e) => set('instituicao')(e.target.value)} required />
              </div>
              <div className="field">
                <label>Campus</label>
                <input type="text" placeholder="Ex.: Januária" value={f.campus} onChange={(e) => set('campus')(e.target.value)} />
              </div>
            </div>
            <div className="field">
              <label>Área de atuação</label>
              <div className="select-wrap">
                <select value={f.area} onChange={(e) => set('area')(e.target.value)}>
                  {['Matemática', 'Matemática Aplicada', 'Estatística', 'Ciências da Natureza', 'Área Técnica', 'Gestão / Coordenação', 'Outra'].map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
                <Icon.chevDown />
              </div>
            </div>
            <div className="lc-grid2">
              <div className="field">
                <label>Senha</label>
                <div className="lc-pass-wrap">
                  <input type={show ? 'text' : 'password'} placeholder="Mínimo 6 caracteres" value={f.senha} onChange={(e) => set('senha')(e.target.value)} required />
                  <button type="button" className="toggle" onClick={() => setShow(!show)} aria-label="Mostrar senha">{show ? <Icon.eyeOff /> : <Icon.eye />}</button>
                </div>
              </div>
              <div className="field">
                <label>Confirmar senha</label>
                <input type={show ? 'text' : 'password'} placeholder="Repita a senha" value={f.confirma} onChange={(e) => set('confirma')(e.target.value)} required
                  style={f.confirma && !confere ? { borderColor: 'var(--red-600)' } : undefined} />
                {f.confirma && !confere && <div className="help" style={{ color: 'var(--red-600)' }}>As senhas não conferem.</div>}
              </div>
            </div>
            <label className="lc-terms">
              <input type="checkbox" checked={aceite} onChange={(e) => setAceite(e.target.checked)} />
              <span>Li e aceito os <a href="#" onClick={(e) => e.preventDefault()}>termos de uso</a> e o <a href="#" onClick={(e) => e.preventDefault()}>compromisso de uso ético e responsável da IA</a> na docência.</span>
            </label>
            <button type="submit" className="btn btn-primary btn-block" style={{ padding: 15 }} disabled={!ready}>Criar conta <Icon.arrowRight /></button>
          </form>
          <p className="lc-foot">Já tem uma conta? <a href="#" onClick={(e) => { e.preventDefault(); onLogin && onLogin(); }}>Entrar</a></p>
        </div>
      </div>
    </div>);

}

Object.assign(window, { Landing, Login, Cadastro });