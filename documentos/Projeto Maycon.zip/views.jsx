/* global React, Icon, Btn, Badge, Select, TextField, PageHead, BiasNote, NOTEBOOK_TEXT,
   USER, AMBIENTES, TRILHA, DOCS, VIDEOS, PROMPTS_EBOOK, IA_INDICACOES, PRATICAS, CURSOS_FILTRO,
   FORUNS, PROVOCACOES, ARTIGOS, INDICADORES, TUTORIAIS */
const { useState: useS } = React;

// ============ NotebookLM block (discreet external link) ============
function NotebookBlock() {
  return (
    <a className="notebook-block" href="https://notebooklm.google.com/" target="_blank" rel="noreferrer">
      <div className="nb-ic"><Icon.notebook /></div>
      <div className="nb-t">
        <b>Apoio à leitura de documentos.</b> {NOTEBOOK_TEXT}
        <span className="nb-link">Acessar o NotebookLM <Icon.arrowUpRight /></span>
      </div>
    </a>
  );
}

// ============ INÍCIO (dashboard) ============
function Inicio({ go }) {
  const hour = new Date().getHours();
  const saud = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite';
  return (
    <div className="view wide fade-up">
      {/* Hero */}
      <div className="card" style={{ overflow: 'hidden', marginBottom: 24, border: 'none',
        background: 'linear-gradient(135deg,#075843,#064E3B 60%,#053d2f)', color: '#fff' }}>
        <div style={{ padding: '34px 36px', display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap', position: 'relative' }}>
          <div style={{ flex: 1, minWidth: 300, position: 'relative', zIndex: 2 }}>
            <div className="eyebrow" style={{ background: 'rgba(255,255,255,.12)', color: 'var(--green-300)' }}>
              <Icon.spark /> Ambiente virtual de apoio à docência
            </div>
            <h1 style={{ fontSize: 34, color: '#fff', marginTop: 14, lineHeight: 1.08, maxWidth: 560 }}>
              {saud}, {USER.name.split(' ')[1]}. Vamos experimentar a IA na sua prática?
            </h1>
            <p style={{ fontSize: 15.5, color: 'rgba(234,250,243,.82)', marginTop: 12, maxWidth: 540, lineHeight: 1.55 }}>
              Apoio à prática docente de Matemática na EPT — voltado à experimentação e à reflexão crítica sobre o uso da Inteligência Artificial na educação.
            </p>
            <div style={{ display: 'flex', gap: 12, marginTop: 22, flexWrap: 'wrap' }}>
              <button className="btn" style={{ background: '#fff', color: 'var(--green-800)' }} onClick={() => go('laboratorio')}>
                <Icon.flask /> Abrir o Laboratório de IA
              </button>
              <button className="btn" style={{ background: 'rgba(255,255,255,.12)', color: '#fff', border: '1px solid rgba(255,255,255,.25)' }} onClick={() => go('formativo')}>
                Continuar minha trilha <Icon.arrowRight />
              </button>
            </div>
          </div>
          <div style={{ display: 'grid', gap: 12, position: 'relative', zIndex: 2 }}>
            {INDICADORES.slice(0, 2).map((s) => {
              const Ic = Icon[s.icon];
              return (
                <div key={s.l} style={{ background: 'rgba(255,255,255,.1)', borderRadius: 16, padding: '16px 20px', minWidth: 200, display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ width: 42, height: 42, borderRadius: 12, background: 'rgba(255,255,255,.16)', display: 'grid', placeItems: 'center' }}><Ic style={{ width: 21, height: 21 }} /></div>
                  <div><div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700 }}>{s.n}</div><div style={{ fontSize: 12.5, color: 'rgba(234,250,243,.7)' }}>{s.l}</div></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 5 ambientes */}
      <div className="section-title"><h2>Os 5 ambientes da plataforma</h2><span className="grow" /><span className="count">Interligados</span></div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(3,1fr)', marginBottom: 28 }}>
        {AMBIENTES.map((a) => {
          const Ic = Icon[a.icon];
          return (
            <button key={a.id} className="card amb-card" onClick={() => go(a.id)}>
              <div className="ic" style={{ background: a.tint, color: a.color }}><Ic /></div>
              <h3>{a.title}</h3>
              <p>{a.desc}</p>
              <span className="go">Acessar <Icon.arrowRight /></span>
            </button>
          );
        })}
        <div className="card" style={{ padding: 0 }}>
          <div style={{ padding: 22 }}><NotebookBlock /></div>
        </div>
      </div>
    </div>
  );
}

// ============ AMBIENTE FORMATIVO ============
// Vídeos: player do YouTube + lista. O docente pode adicionar novos vídeos (cola a URL).
function ytId(url) {
  const m = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:live\/|watch\?v=|embed\/|v\/|shorts\/))([\w-]{11})/);
  return m ? m[1] : (/^[\w-]{11}$/.test(url) ? url : null);
}

function VideosTab() {
  const [list, setList] = useS(VIDEOS);
  const [active, setActive] = useS(0);
  const [adding, setAdding] = useS(false);
  const [form, setForm] = useS({ url: '', titulo: '', autor: '', tag: 'Aula', desc: '' });
  const cur = list[active];

  const submit = () => {
    const id = ytId(form.url);
    if (!id || !form.titulo.trim()) return;
    const novo = { id, titulo: form.titulo.trim(), autor: form.autor.trim() || 'Equipe IAprofEPT', dur: 'Vídeo', tag: form.tag, desc: form.desc.trim() };
    setList((l) => [novo, ...l]); setActive(0); setAdding(false);
    setForm({ url: '', titulo: '', autor: '', tag: 'Aula', desc: '' });
  };

  return (
    <div>
      <div className="section-title" style={{ marginBottom: 16 }}>
        <Icon.video style={{ width: 18, height: 18, color: 'var(--green-700)' }} />
        <h2 style={{ fontSize: 16 }}>Vídeos do ambiente formativo</h2>
        <span className="count">{list.length} {list.length === 1 ? 'vídeo' : 'vídeos'}</span>
        <span className="grow" />
        <Btn sm icon={adding ? 'close' : 'upload'} variant={adding ? 'ghost' : 'primary'} onClick={() => setAdding(!adding)}>
          {adding ? 'Cancelar' : 'Adicionar vídeo'}
        </Btn>
      </div>

      {adding && (
        <div className="card card-pad fade-up" style={{ marginBottom: 18, border: '1.5px solid var(--green-300)' }}>
          <div className="grid g2">
            <TextField label="Link do vídeo (YouTube)" req placeholder="https://www.youtube.com/watch?v=..." value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} help={form.url && !ytId(form.url) ? '⚠ Link do YouTube não reconhecido' : 'Cole a URL do YouTube (vídeo, live ou compartilhamento).'} />
            <TextField label="Título" req placeholder="Ex.: Aula 1 — Funções e o mundo do trabalho" value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} />
            <TextField label="Autor / canal" placeholder="Ex.: Prof. Maycon Magalhães" value={form.autor} onChange={(e) => setForm({ ...form, autor: e.target.value })} />
            <Select label="Categoria" value={form.tag} onChange={(v) => setForm({ ...form, tag: v })} options={['Aula', 'Palestra', 'Tutorial', 'Webinar', 'Documentário']} />
          </div>
          <div style={{ marginTop: 14 }}><TextField area label="Descrição (opcional)" placeholder="Sobre o que é o vídeo?" value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} /></div>
          <div style={{ marginTop: 14, display: 'flex', gap: 10 }}>
            <Btn icon="check" disabled={!ytId(form.url) || !form.titulo.trim()} onClick={submit}>Adicionar à lista</Btn>
            <Btn variant="ghost" onClick={() => setAdding(false)}>Cancelar</Btn>
          </div>
        </div>
      )}

      <div className="grid" style={{ gridTemplateColumns: '1.7fr 1fr', alignItems: 'start', gap: 20 }}>
        {/* Player */}
        <div className="card" style={{ overflow: 'hidden' }}>
          <div style={{ position: 'relative', width: '100%', aspectRatio: '16 / 9', background: '#000' }}>
            <iframe
              key={cur.id}
              src={`https://www.youtube.com/embed/${cur.id}?rel=0`}
              title={cur.titulo}
              style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 'none' }}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          </div>
          <div className="card-pad">
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
              <Badge tone="green">{cur.tag}</Badge>
              <span style={{ fontSize: 12.5, color: 'var(--ink-400)' }}>{cur.autor}</span>
            </div>
            <h3 style={{ fontSize: 19, lineHeight: 1.25, marginBottom: 8 }}>{cur.titulo}</h3>
            {cur.desc && <p style={{ fontSize: 14, color: 'var(--ink-500)', lineHeight: 1.55 }}>{cur.desc}</p>}
            <div style={{ marginTop: 14, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <a className="btn btn-ghost btn-sm" href={`https://www.youtube.com/watch?v=${cur.id}`} target="_blank" rel="noreferrer"><Icon.arrowUpRight /> Abrir no YouTube</a>
              <Btn variant="ghost" sm icon="bookmark">Salvar para depois</Btn>
            </div>
          </div>
        </div>

        {/* Playlist */}
        <div className="card" style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 9 }}>
            <Icon.list style={{ width: 17, height: 17, color: 'var(--ink-500)' }} />
            <span style={{ fontSize: 13.5, fontWeight: 700, color: 'var(--ink-700)' }}>Lista de reprodução</span>
          </div>
          <div style={{ maxHeight: 460, overflowY: 'auto' }}>
            {list.map((v, i) => (
              <button key={i} className="row-item" onClick={() => setActive(i)}
                style={{ width: '100%', textAlign: 'left', background: i === active ? 'var(--green-50)' : 'transparent', border: 'none', cursor: 'pointer' }}>
                <div style={{ position: 'relative', width: 92, height: 56, borderRadius: 9, overflow: 'hidden', flex: 'none', background: '#000' }}>
                  <img src={`https://img.youtube.com/vi/${v.id}/mqdefault.jpg`} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  <span style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,.18)' }}>
                    <span style={{ width: 26, height: 26, borderRadius: '50%', background: 'rgba(255,255,255,.92)', display: 'grid', placeItems: 'center' }}>
                      <Icon.play style={{ width: 16, height: 16, color: 'var(--green-800)' }} />
                    </span>
                  </span>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700, color: i === active ? 'var(--green-800)' : 'var(--ink-900)', lineHeight: 1.3, marginBottom: 4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{v.titulo}</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-400)', display: 'flex', alignItems: 'center', gap: 7 }}>
                    <span>{v.autor}</span>{i === active && <span style={{ color: 'var(--green-600)', fontWeight: 700 }}>● tocando</span>}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ AMBIENTE FORMATIVO ============
function Formativo() {
  const [tab, setTab] = useS('trilhas');
  return (
    <div className="view fade-up">
      <PageHead eyebrow="Formação continuada" eyebrowIcon="book" title="Ambiente Formativo"
        sub="Trilhas de aprendizagem, materiais orientadores e um e-book de prompts para a sua prática docente em Matemática." />
      <div className="tabs" style={{ width: 'fit-content', marginBottom: 22 }}>
        {[['trilhas', 'Trilhas'], ['videos', 'Vídeos'], ['materiais', 'Materiais & legislação'], ['ias', 'IAs & E-book de prompts']].map(([id, l]) => (
          <button key={id} className={`tab${tab === id ? ' on' : ''}`} onClick={() => setTab(id)}>{l}</button>
        ))}
      </div>

      {tab === 'trilhas' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {TRILHA.map((m) => (
            <div key={m.n} className="card card-pad" style={{ display: 'flex', gap: 18, alignItems: 'center', opacity: m.status === 'lock' ? 0.72 : 1 }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, flex: 'none', display: 'grid', placeItems: 'center', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 20,
                background: m.status === 'done' ? 'var(--green-800)' : m.status === 'now' ? 'var(--green-50)' : 'var(--surface-2)',
                color: m.status === 'done' ? '#fff' : m.status === 'now' ? 'var(--green-700)' : 'var(--ink-400)' }}>
                {m.status === 'done' ? <Icon.check style={{ width: 24, height: 24 }} /> : m.n}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4, flexWrap: 'wrap' }}>
                  <h3 style={{ fontSize: 16.5 }}>Módulo {m.n} · {m.title}</h3>
                  {m.status === 'now' && <Badge tone="green">Em andamento</Badge>}
                  {m.status === 'done' && <Badge tone="green" icon="check">Concluído</Badge>}
                </div>
                <p style={{ fontSize: 13.5, color: 'var(--ink-500)', lineHeight: 1.5, marginBottom: 10 }}>{m.desc}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                  <span style={{ fontSize: 12.5, color: 'var(--ink-400)', display: 'flex', alignItems: 'center', gap: 6 }}><Icon.play style={{ width: 14, height: 14 }} />{m.lessons} aulas</span>
                  <span style={{ fontSize: 12.5, color: 'var(--ink-400)', display: 'flex', alignItems: 'center', gap: 6 }}><Icon.clock style={{ width: 14, height: 14 }} />{m.mins} min</span>
                  <div className="progress" style={{ flex: 1, maxWidth: 200 }}><i style={{ width: `${m.progress}%` }} /></div>
                </div>
              </div>
              <Btn variant={m.status === 'lock' ? 'ghost' : 'primary'} sm disabled={m.status === 'lock'} icon={m.status === 'lock' ? 'shield' : 'play'}>
                {m.status === 'done' ? 'Revisar' : m.status === 'now' ? 'Continuar' : 'Bloqueado'}
              </Btn>
            </div>
          ))}
          <div className="card card-pad" style={{ background: 'var(--green-50)', border: '1px solid var(--green-100)' }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <Icon.edit style={{ width: 20, height: 20, color: 'var(--green-700)', flex: 'none', marginTop: 2 }} />
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: 15, marginBottom: 6, color: 'var(--green-900)' }}>Diário de reflexão</h3>
                <p style={{ fontSize: 13.5, color: 'var(--ink-500)', marginBottom: 10 }}>Registre suas reflexões sobre o Módulo 2 — Ética no uso de IA.</p>
                <textarea placeholder="O que mudou na sua forma de pensar o uso de IA depois deste módulo?" style={{ background: '#fff' }} />
                <div style={{ marginTop: 10 }}><Btn sm icon="check">Salvar reflexão</Btn></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'materiais' && (
        <div className="card" style={{ overflow: 'hidden' }}>
          {DOCS.map((d, i) => {
            const Ic = d.kind === 'video' ? Icon.play : Icon.doc;
            return (
              <div key={i} className="row-item">
                <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--green-50)', color: 'var(--green-700)', display: 'grid', placeItems: 'center', flex: 'none' }}><Ic style={{ width: 19, height: 19 }} /></div>
                <div style={{ flex: 1 }}><div style={{ fontSize: 14.5, fontWeight: 600, color: 'var(--ink-900)' }}>{d.t}</div></div>
                <Badge>{d.tag}</Badge>
                <Btn variant="ghost" sm icon="arrowUpRight">Abrir</Btn>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'videos' && <VideosTab />}

      {tab === 'ias' && (
        <div className="grid g2" style={{ alignItems: 'start' }}>
          <div className="card card-pad">
            <div className="section-title"><Icon.bulb style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>IAs indicadas para a prática</h2></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {IA_INDICACOES.map((x, i) => (
                <div key={i} style={{ paddingBottom: 14, borderBottom: i < IA_INDICACOES.length - 1 ? '1px solid var(--line)' : 'none' }}>
                  <div style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 3 }}>{x.nome}</div>
                  <div style={{ fontSize: 13, color: 'var(--ink-500)', lineHeight: 1.5 }}>{x.uso}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="card card-pad">
            <div className="section-title"><Icon.copy style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>E-book de prompts</h2><span className="grow" /><Badge tone="green">Copie e use</Badge></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {PROMPTS_EBOOK.map((p, i) => (
                <div key={i} style={{ background: 'var(--surface-2)', borderRadius: 12, padding: 14 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <span style={{ fontSize: 13.5, fontWeight: 700 }}>{p.titulo}</span><Badge tone="green">{p.tag}</Badge>
                    <span className="grow" />
                    <button className="btn btn-ghost btn-sm" onClick={() => navigator.clipboard && navigator.clipboard.writeText(p.texto)}><Icon.copy /> Copiar</button>
                  </div>
                  <p style={{ fontSize: 12.5, color: 'var(--ink-500)', lineHeight: 1.5, fontFamily: 'var(--font-ui)' }}>{p.texto}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============ REPOSITÓRIO ============
function Repositorio() {
  const [filtro, setFiltro] = useS('Todos');
  const [busca, setBusca] = useS('');
  const [show, setShow] = useS(false);
  const list = PRATICAS.filter((p) => (filtro === 'Todos' || p.curso === filtro) && (!busca || (p.titulo + p.tema + p.autor).toLowerCase().includes(busca.toLowerCase())));
  return (
    <div className="view fade-up">
      <PageHead eyebrow="Curadoria colaborativa" eyebrowIcon="repo" title="Repositório de Práticas Docentes"
        sub="Compartilhe sequências didáticas e experiências de sala de aula. Filtre por curso ou tema e exporte as produções.">
        <Btn icon="upload" onClick={() => setShow(true)}>Compartilhar prática</Btn>
      </PageHead>

      <div className="card card-pad" style={{ marginBottom: 20, display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap' }}>
        <div className="search" style={{ margin: 0, width: 260 }}><Icon.search /><input placeholder="Buscar por tema, curso ou autor…" value={busca} onChange={(e) => setBusca(e.target.value)} /></div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {CURSOS_FILTRO.map((c) => <button key={c} className={`chip${filtro === c ? ' on' : ''}`} onClick={() => setFiltro(c)}>{c}</button>)}
        </div>
      </div>

      {show && (
        <div className="card card-pad fade-up" style={{ marginBottom: 20, border: '1.5px solid var(--green-300)' }}>
          <div className="section-title"><Icon.upload style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>Compartilhar uma prática</h2><span className="grow" /><button className="icon-btn" style={{ width: 34, height: 34 }} onClick={() => setShow(false)}><Icon.close /></button></div>
          <div className="grid g2">
            <TextField label="Título da prática" req placeholder="Ex.: Funções afins na dosagem de medicamentos" />
            <Select label="Curso técnico" req placeholder="Selecione" value="" onChange={() => {}} options={CURSOS_FILTRO.slice(1)} />
          </div>
          <div style={{ marginTop: 14 }}><TextField area label="Como foi essa prática em sala?" placeholder="Conte o contexto, os resultados e o que você faria diferente…" /></div>
          <div style={{ marginTop: 14, display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <Btn variant="ghost" icon="upload">Anexar arquivo</Btn>
            <Btn variant="ghost" icon="link">Adicionar link</Btn>
            <span className="grow" />
            <Btn icon="check" onClick={() => setShow(false)}>Publicar no repositório</Btn>
          </div>
        </div>
      )}

      <div className="section-title"><h2 style={{ fontSize: 17 }}>{list.length} práticas</h2></div>
      <div className="grid g2">
        {list.map((p, i) => (
          <div key={i} className="card card-pad" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}><Badge tone="green">{p.curso}</Badge><Badge>{p.tema}</Badge><Badge tone="amber">{p.tipo}</Badge></div>
            <h3 style={{ fontSize: 16.5, lineHeight: 1.3 }}>{p.titulo}</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, fontSize: 12.5, color: 'var(--ink-400)' }}>
              <span>{p.autor}</span><span>·</span><span>há {p.dias} dias</span>
              <span style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 5 }}><Icon.star style={{ width: 14, height: 14 }} />{p.likes}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}><Icon.doc style={{ width: 14, height: 14 }} />{p.files}</span>
            </div>
            <div style={{ borderTop: '1px solid var(--line)', paddingTop: 12, display: 'flex', gap: 8 }}>
              <Btn variant="ghost" sm icon="chat">Comentar</Btn>
              <span className="grow" />
              <Btn variant="soft" sm icon="download">PDF</Btn>
              <Btn variant="ghost" sm>DOCX</Btn>
              <Btn variant="ghost" sm>HTML</Btn>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ REFLEXÃO CRÍTICA ============
function Reflexao() {
  const [prov, setProv] = useS(0);
  return (
    <div className="view fade-up">
      <PageHead eyebrow="Uso crítico e ético" eyebrowIcon="scale" title="Painel de Reflexão Crítica"
        sub="Um espaço para problematizar — não automatizar. Discuta os limites éticos e políticos do uso da IA na docência em Matemática." />

      <div className="card card-pad" style={{ marginBottom: 22, background: 'var(--red-50)', border: '1.5px solid var(--red-100)' }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--red-600)', color: '#fff', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon.bulb style={{ width: 22, height: 22 }} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--red-600)', marginBottom: 6 }}>Provocação formativa</div>
            <h2 style={{ fontSize: 21, color: 'var(--red-700)', lineHeight: 1.25, maxWidth: 720 }}>{PROVOCACOES[prov]}</h2>
            <div style={{ marginTop: 14, display: 'flex', gap: 10 }}>
              <button className="btn btn-danger btn-sm" onClick={() => setProv((prov + 1) % PROVOCACOES.length)}><Icon.refresh /> Outra provocação</button>
              <Btn variant="ghost" sm icon="pencil">Responder no diário</Btn>
            </div>
          </div>
        </div>
      </div>

      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div>
          <div className="section-title"><Icon.chat style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>Fóruns de discussão</h2></div>
          <div className="card" style={{ overflow: 'hidden' }}>
            {FORUNS.map((f, i) => (
              <div key={i} className="row-item" style={{ alignItems: 'flex-start', cursor: 'pointer' }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--green-50)', color: 'var(--green-700)', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon.message style={{ width: 18, height: 18 }} /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 600, lineHeight: 1.35, marginBottom: 5 }}>{f.titulo}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12.5, color: 'var(--ink-400)' }}>
                    <Badge tone="red">{f.tag}</Badge><span>{f.autor}</span><span>·</span><span>{f.respostas} respostas</span>
                    {f.ativo && <span style={{ color: 'var(--green-600)', fontWeight: 700 }}>● ativo</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 14 }}><Btn variant="ghost" block icon="edit">Abrir novo tópico</Btn></div>
        </div>

        <div>
          <div className="section-title"><Icon.doc style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>Artigos & entrevistas</h2></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {ARTIGOS.map((a, i) => (
              <div key={i} className="card card-pad" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--surface-2)', color: 'var(--ink-700)', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon.doc style={{ width: 20, height: 20 }} /></div>
                <div style={{ flex: 1 }}><div style={{ fontSize: 14.5, fontWeight: 700, lineHeight: 1.3, marginBottom: 4 }}>{a.t}</div><div style={{ fontSize: 12.5, color: 'var(--ink-400)' }}>{a.autor}</div></div>
                <Badge tone="amber">{a.tag}</Badge>
              </div>
            ))}
            <div className="card card-pad" style={{ background: 'var(--green-50)', border: '1px solid var(--green-100)' }}>
              <BiasNote>Combater o uso acrítico da IA é parte da docência. Antes de aplicar qualquer conteúdo gerado, pergunte-se: a quem isso serve e quem é representado?</BiasNote>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ SUPORTE ============
function Suporte() {
  return (
    <div className="view fade-up">
      <PageHead eyebrow="Acompanhamento & apoio" eyebrowIcon="help" title="Canal de Suporte"
        sub="Apoio técnico e pedagógico, tutoriais e o seu portfólio formativo de engajamento na plataforma." />

      <div className="section-title"><h2 style={{ fontSize: 17 }}>Seu portfólio formativo</h2></div>
      <div className="grid g4" style={{ marginBottom: 28 }}>
        {INDICADORES.map((s) => {
          const Ic = Icon[s.icon];
          return (
            <div key={s.l} className="card card-pad">
              <div className="stat">
                <div className="ic" style={{ background: s.tint, color: s.color }}><Ic style={{ width: 20, height: 20 }} /></div>
                <div className="n" style={{ marginTop: 6 }}>{s.n}</div>
                <div className="l">{s.l}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div>
          <div className="section-title"><Icon.play style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>Tutoriais de uso</h2></div>
          <div className="card" style={{ overflow: 'hidden' }}>
            {TUTORIAIS.map((t, i) => (
              <div key={i} className="row-item">
                <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--green-50)', color: 'var(--green-700)', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon.play style={{ width: 18, height: 18 }} /></div>
                <div style={{ flex: 1, fontSize: 14.5, fontWeight: 600 }}>{t.t}</div>
                <span style={{ fontSize: 12.5, color: 'var(--ink-400)' }}>{t.mins} min</span>
                <Btn variant="ghost" sm>Assistir</Btn>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="section-title"><Icon.alert style={{ width: 18, height: 18, color: 'var(--green-700)' }} /><h2 style={{ fontSize: 16 }}>Reportar erro ou sugestão</h2></div>
          <div className="card card-pad">
            <Select label="Tipo de contato" placeholder="Selecione" value="" onChange={() => {}} options={['Reportar um erro', 'Enviar sugestão', 'Dúvida pedagógica', 'Dúvida técnica']} />
            <div style={{ marginTop: 14 }}><TextField area label="Descreva sua mensagem" placeholder="Conte com o máximo de detalhes…" /></div>
            <div style={{ marginTop: 14 }}><Btn block icon="send">Enviar para a equipe</Btn></div>
            <div style={{ marginTop: 14 }}><NotebookBlock /></div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Inicio, Formativo, Repositorio, Reflexao, Suporte, NotebookBlock });
