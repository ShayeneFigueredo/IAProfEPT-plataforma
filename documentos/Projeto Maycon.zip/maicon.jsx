/* global React, Icon, runAI */
const { useState: useM, useRef, useEffect: useME } = React;

// mAIcon avatar — illustrated portrait of Prof. mAIcon
function MaiconFace({ size = 30 }) {
  return (
    <img src="assets/maicon.png" alt="Prof. mAIcon" width={size} height={size}
      style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover', objectPosition: 'center 12%', display: 'block' }} />
  );
}

const MAICON_SYS = `Você é o "Prof. mAIcon", o assistente virtual da plataforma IAprofEPT, um ambiente de apoio à docência em Matemática na Educação Profissional e Tecnológica (EPT).

ESCOPO ESTRITO: você responde APENAS sobre (1) como navegar e usar a plataforma e (2) uso ético, crítico e responsável da IA no contexto da Educação Matemática. Se perguntarem algo fora disso (ex.: resolver uma conta, fofoca, assuntos pessoais), redirecione gentilmente para esses dois temas.

A plataforma tem 5 ambientes: Ambiente Formativo (trilhas, materiais, e-book de prompts), Laboratório de IA (gera exercícios, atividades interdisciplinares, roteiros de podcast e planos de aula a partir de menus — nunca de prompt vazio), Repositório de Práticas (compartilhar e exportar sequências didáticas), Reflexão Crítica (fóruns, artigos, provocações éticas) e Suporte (tutoriais, portfólio, reportar erros).

Seja caloroso, breve (2 a 5 frases), em português do Brasil, e sempre reforce a autonomia e o senso crítico do docente. Lembre que todo conteúdo de IA deve ser revisado pelo professor.`;

const MAICON_FALLBACKS = {
  default: 'Posso te orientar a navegar pela plataforma ou refletir sobre o uso ético da IA na sua prática. Sobre o que você quer falar? 🙂',
  lab: 'No Laboratório de IA você escolhe os parâmetros em menus — área, nível, curso técnico — e o sistema monta o prompt pedagógico nos bastidores. Você nunca parte de uma caixa vazia! Lembre de revisar o gabarito antes de usar.',
  etica: 'Ótima pergunta. A IA é uma parceira, não uma substituta do seu julgamento. Sempre verifique cálculos, questione os contextos gerados (quem é representado?) e adapte tudo à sua turma. A decisão pedagógica é sempre sua.',
  export: 'No Repositório, cada prática tem botões de exportação em PDF, DOCX e HTML — é só clicar no formato desejado no rodapé do card. 📄',
};

function pickFallback(q) {
  const t = q.toLowerCase();
  if (/(laborat|exerc|gerar|plano|prompt)/.test(t)) return MAICON_FALLBACKS.lab;
  if (/(étic|etic|vies|viés|bias|crític|critic|respons)/.test(t)) return MAICON_FALLBACKS.etica;
  if (/(export|pdf|docx|baixar|download|repositó)/.test(t)) return MAICON_FALLBACKS.export;
  return MAICON_FALLBACKS.default;
}

const SUGESTOES = ['Como gero exercícios?', 'É ético usar IA para corrigir?', 'Como exporto uma prática?', 'O que é o eixo integrador?'];

function Maicon() {
  const [open, setOpen] = useM(false);
  const [msgs, setMsgs] = useM([{ role: 'bot', text: 'Oi! Eu sou o Prof. mAIcon 👋 Estou aqui para te ajudar a navegar pela plataforma e a usar a IA de forma ética na sua prática. Como posso ajudar?' }]);
  const [input, setInput] = useM('');
  const [busy, setBusy] = useM(false);
  const scroller = useRef(null);

  useME(() => { if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight; }, [msgs, busy, open]);

  const send = async (text) => {
    const q = (text || input).trim();
    if (!q || busy) return;
    setMsgs((m) => [...m, { role: 'user', text: q }]); setInput(''); setBusy(true);
    const history = msgs.map((m) => `${m.role === 'bot' ? 'mAIcon' : 'Docente'}: ${m.text}`).join('\n');
    const out = await runAI(MAICON_SYS, `Histórico:\n${history}\n\nNova pergunta do docente: ${q}`, pickFallback(q));
    setMsgs((m) => [...m, { role: 'bot', text: out }]); setBusy(false);
  };

  if (!open) {
    return (
      <button className="maicon-fab" onClick={() => setOpen(true)}>
        <span className="mface"><MaiconFace size={38} /></span>
        <span className="mtxt">Prof. mAIcon<small>Tire suas dúvidas</small></span>
      </button>
    );
  }

  return (
    <div className="maicon-panel fade-up">
      <div className="maicon-head">
        <span className="mface"><MaiconFace size={42} /></span>
        <div>
          <div className="h-name">Prof. mAIcon</div>
          <div className="h-status"><i />Assistente da plataforma</div>
        </div>
        <button className="close" onClick={() => setOpen(false)}><Icon.close /></button>
      </div>
      <div className="maicon-msgs" ref={scroller}>
        {msgs.map((m, i) => <div key={i} className={`msg ${m.role}`}>{m.text}</div>)}
        {busy && <div className="msg bot"><span className="dots" style={{ color: 'var(--green-600)' }}><span>●</span><span>●</span><span>●</span></span></div>}
      </div>
      {msgs.length <= 1 && (
        <div className="maicon-suggest">
          {SUGESTOES.map((s) => <button key={s} onClick={() => send(s)}>{s}</button>)}
        </div>
      )}
      <div className="maicon-input">
        <input placeholder="Escreva sua dúvida…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} />
        <button className="send" disabled={busy || !input.trim()} onClick={() => send()}><Icon.send /></button>
      </div>
    </div>
  );
}

Object.assign(window, { Maicon, MaiconFace });
