/* global React */
// ============ Icon set (stroke-based, 24x24) ============
const I = (paths, opts = {}) => (props) =>
<svg viewBox="0 0 24 24" fill={opts.fill || 'none'} stroke={opts.fill ? 'none' : 'currentColor'}
strokeWidth={opts.sw || 1.8} strokeLinecap="round" strokeLinejoin="round" {...props}>
    {paths}
  </svg>;


const Icon = {
  home: I(<><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9.5" /><path d="M9.5 21v-6h5v6" /></>),
  book: I(<><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z" /><path d="M4 5.5V20.5" /><path d="M9 7.5h7M9 11h5" /></>),
  flask: I(<><path d="M9 3h6" /><path d="M10 3v6.5L5.2 17.6A2 2 0 0 0 6.9 20.7h10.2a2 2 0 0 0 1.7-3.1L14 9.5V3" /><path d="M8 14h8" /></>),
  repo: I(<><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5H9l2 2.2h8.5A1.5 1.5 0 0 1 21 8.7V18a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18z" /><path d="M8 13h8M8 16h5" /></>),
  scale: I(<><path d="M12 3v18M7 7h10" /><path d="M7 7 4 14h6zM17 7l-3 7h6z" /><path d="M2.5 14a3.5 3.5 0 0 0 7 0M14.5 14a3.5 3.5 0 0 0 7 0" /></>),
  help: I(<><circle cx="12" cy="12" r="9" /><path d="M9.5 9.5a2.5 2.5 0 0 1 4.6 1.3c0 1.7-2.6 2.2-2.6 3.7" /><path d="M12 17.5h.01" /></>),
  spark: I(<><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1" /><circle cx="12" cy="12" r="3.2" /></>),
  search: I(<><circle cx="11" cy="11" r="7" /><path d="m20 20-3.2-3.2" /></>),
  bell: I(<><path d="M6 9a6 6 0 0 1 12 0c0 5 2 6 2 6H4s2-1 2-6" /><path d="M10 20a2 2 0 0 0 4 0" /></>),
  arrowRight: I(<><path d="M5 12h14M13 6l6 6-6 6" /></>),
  arrowUpRight: I(<><path d="M7 17 17 7M9 7h8v8" /></>),
  logout: I(<><path d="M14 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-2" /><path d="M10 12h11M18 8l4 4-4 4" /></>),
  chevDown: I(<><path d="m6 9 6 6 6-6" /></>),
  check: I(<><path d="M5 12.5 10 17.5 19.5 7" /></>),
  checkCircle: I(<><circle cx="12" cy="12" r="9" /><path d="m8.5 12 2.3 2.3 4.7-4.7" /></>),
  alert: I(<><path d="M12 3 2 20h20z" /><path d="M12 9v5M12 17.5h.01" /></>),
  shield: I(<><path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6z" /><path d="M9 12l2 2 4-4" /></>),
  send: I(<><path d="M5 12 21 4l-6 17-3-7z" /><path d="m12 14 9-10" /></>),
  close: I(<><path d="M6 6 18 18M18 6 6 18" /></>),
  download: I(<><path d="M12 3v12M7 11l5 5 5-5" /><path d="M4 19h16" /></>),
  upload: I(<><path d="M12 16V4M7 9l5-5 5 5" /><path d="M4 19h16" /></>),
  filter: I(<><path d="M3 5h18M6 12h12M10 19h4" /></>),
  play: I(<><circle cx="12" cy="12" r="9" /><path d="M10 8.5 16 12l-6 3.5z" fill="currentColor" stroke="none" /></>),
  doc: I(<><path d="M7 3h7l5 5v13a0 0 0 0 1 0 0H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" /><path d="M14 3v5h5" /><path d="M9 13h6M9 16h4" /></>),
  link: I(<><path d="M9 15 15 9" /><path d="M10.5 6.5 13 4a4 4 0 0 1 6 6l-2.5 2.5M13.5 17.5 11 20a4 4 0 0 1-6-6l2.5-2.5" /></>),
  chat: I(<><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h13A1.5 1.5 0 0 1 20 5.5v9a1.5 1.5 0 0 1-1.5 1.5H9l-4 3.5V15.5H5.5A1.5 1.5 0 0 1 4 14z" /></>),
  users: I(<><circle cx="9" cy="8" r="3" /><path d="M3 19a6 6 0 0 1 12 0" /><path d="M16 5.5a3 3 0 0 1 0 5M21 19a6 6 0 0 0-4-5.7" /></>),
  clock: I(<><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3.5 2" /></>),
  target: I(<><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1.3" fill="currentColor" stroke="none" /></>),
  podcast: I(<><circle cx="12" cy="8" r="4" /><path d="M12 12v3" /><path d="M8.5 19c0-2 1.5-3.5 3.5-3.5S15.5 17 15.5 19" /><path d="M7 20.5h10" /></>),
  layers: I(<><path d="m12 3 9 5-9 5-9-5z" /><path d="m3 13 9 5 9-5" /></>),
  edit: I(<><path d="M4 20h4L19 9l-4-4L4 16z" /><path d="M14 6l4 4" /></>),
  copy: I(<><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></>),
  bookmark: I(<><path d="M6 4h12v16l-6-4-6 4z" /></>),
  graph: I(<><path d="M4 19V5M4 19h16" /><path d="M7 15l3-4 3 2 4-6" /></>),
  bulb: I(<><path d="M9 18h6M10 21h4" /><path d="M12 3a6 6 0 0 0-3.5 10.9c.5.4.5 1 .5 1.6V16h6v-.5c0-.6 0-1.2.5-1.6A6 6 0 0 0 12 3z" /></>),
  star: I(<><path d="m12 3 2.6 5.6 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.4l6-.8z" /></>),
  trophy: I(<><path d="M7 4h10v4a5 5 0 0 1-10 0z" /><path d="M7 6H4v1a3 3 0 0 0 3 3M17 6h3v1a3 3 0 0 1-3 3" /><path d="M12 13v3M9 20h6M10 16h4l.5 4h-5z" /></>),
  fire: I(<><path d="M12 3c1 3-2 4-2 7a2.5 2.5 0 0 0 5 0c0-.7-.2-1.3-.5-1.8C16 10 17 12.5 17 14.5a5 5 0 0 1-10 0C7 10.5 10 7 12 3z" /></>),
  notebook: I(<><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M9 3v18" /><path d="M12 8h4M12 12h4" /></>),
  settings: I(<><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1.3l1.7-1.3-1.7-3-2 .8a7 7 0 0 0-2.2-1.3L14 4h-4l-.4 2.6a7 7 0 0 0-2.2 1.3l-2-.8-1.7 3 1.7 1.3A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.3l-1.7 1.3 1.7 3 2-.8a7 7 0 0 0 2.2 1.3L10 20h4l.4-2.6a7 7 0 0 0 2.2-1.3l2 .8 1.7-3-1.7-1.3A7 7 0 0 0 19 12z" /></>),
  refresh: I(<><path d="M4 12a8 8 0 0 1 13.5-5.8L20 8" /><path d="M20 4v4h-4" /><path d="M20 12a8 8 0 0 1-13.5 5.8L4 16" /><path d="M4 20v-4h4" /></>),
  list: I(<><path d="M8 6h12M8 12h12M8 18h12" /><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none" /><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none" /><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none" /></>),
  pin: I(<><path d="M12 21s7-5.5 7-11a7 7 0 0 0-14 0c0 5.5 7 11 7 11z" /><circle cx="12" cy="10" r="2.5" /></>),
  globe: I(<><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18" /></>),
  message: I(<><path d="M21 11.5a8 8 0 0 1-11.5 7.2L4 20l1.3-5A8 8 0 1 1 21 11.5z" /></>),
  pencil: I(<><path d="M4 20h4L19 9l-4-4L4 16z" /><path d="M14 6l4 4" /></>),
  briefcase: I(<><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /><path d="M3 12h18" /></>),
  calc: I(<><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M8 7h8" /><path d="M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01" /></>),
  eye: I(<><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></>),
  eyeOff: I(<><path d="M10.6 6.1A9 9 0 0 1 12 6c6 0 10 6 10 6a16 16 0 0 1-3 3.4M6.3 6.3A16 16 0 0 0 2 12s4 6 10 6a9 9 0 0 0 3.7-.8" /><path d="M3 3l18 18" /><path d="M9.5 9.5a3 3 0 0 0 4.2 4.2" /></>),
  video: I(<><rect x="3" y="5" width="13" height="14" rx="2.5" /><path d="M16 9.5 21 7v10l-5-2.5z" /></>)
};

// ============ Logo ============
function Logo({ size = 34, dark = false }) {
  // Modern monogram: emerald squircle, a node-graph "spark" forming a rising data path,
  // with a single red accent node (the ethical-alert dot the brand reserves red for).
  const id = React.useId();
  return (
    <div className="brand" style={{ textAlign: "left" }}>
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-label="IAprofEPT">
        <defs>
          <linearGradient id={`g${id}`} x1="6" y1="6" x2="42" y2="44" gradientUnits="userSpaceOnUse">
            <stop stopColor="#0a7a5c" /><stop offset="1" stopColor="#064E3B" />
          </linearGradient>
        </defs>
        <rect x="2" y="2" width="44" height="44" rx="14" fill={`url(#g${id})`} />
        {/* rising data path (math/AI growth) */}
        <path d="M11 33 L19 25 L26 29 L37 15" stroke="#6ed3b3" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {/* nodes */}
        <circle cx="11" cy="33" r="3" fill="#fff" />
        <circle cx="19" cy="25" r="3" fill="#fff" />
        <circle cx="26" cy="29" r="3" fill="#fff" />
        {/* terminal node = red accent (the one place brand uses red) */}
        <circle cx="37" cy="15" r="3.6" fill="#DC2626" />
        <circle cx="37" cy="15" r="6.5" stroke="#DC2626" strokeOpacity="0.35" strokeWidth="1.5" />
      </svg>
      <div className="brand-word" style={{ lineHeight: 1.05 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: size * 0.5,
          color: dark ? 'var(--green-800)' : '#fff', letterSpacing: '-0.02em' }}>
          IA<span style={{ color: dark ? 'var(--green-600)' : 'var(--green-300)' }}>prof</span>
          <span style={{ color: 'var(--red-600)' }}>EPT</span>
        </div>
        <div style={{ fontSize: size * 0.235, fontWeight: 600, letterSpacing: '.04em',
          color: dark ? 'var(--ink-400)' : 'rgba(214,241,230,.65)' }}>
          IA na Educação Matemática
        </div>
      </div>
    </div>);

}

Object.assign(window, { Icon, Logo });