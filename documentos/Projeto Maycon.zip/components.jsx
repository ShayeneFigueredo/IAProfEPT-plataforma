/* global React, Icon, VALIDATION_NOTE */
// ============ Shared UI components ============

function Btn({ variant = 'primary', sm, block, icon, iconRight, children, ...p }) {
  const Ic = icon ? Icon[icon] : null;
  const IcR = iconRight ? Icon[iconRight] : null;
  return (
    <button className={`btn btn-${variant}${sm ? ' btn-sm' : ''}${block ? ' btn-block' : ''}`} {...p}>
      {Ic && <Ic />}{children}{IcR && <IcR />}
    </button>
  );
}

function Badge({ tone, icon, children }) {
  const Ic = icon ? Icon[icon] : null;
  return <span className={`badge ${tone || ''}`}>{Ic && <Ic />}{children}</span>;
}

function Select({ label, req, value, onChange, options, placeholder, help }) {
  return (
    <div className="field">
      {label && <label>{label}{req && <span className="req">*</span>}</label>}
      <div className="select-wrap">
        <select value={value} onChange={(e) => onChange(e.target.value)}>
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <Icon.chevDown />
      </div>
      {help && <div className="help">{help}</div>}
    </div>
  );
}

function TextField({ label, req, help, area, ...p }) {
  return (
    <div className="field">
      {label && <label>{label}{req && <span className="req">*</span>}</label>}
      {area ? <textarea {...p} /> : <input type="text" {...p} />}
      {help && <div className="help">{help}</div>}
    </div>
  );
}

function PageHead({ eyebrow, eyebrowIcon, title, sub, children }) {
  const Ic = eyebrowIcon ? Icon[eyebrowIcon] : null;
  return (
    <div className="page-head" style={{ display: 'flex', alignItems: 'flex-end', gap: 20, flexWrap: 'wrap' }}>
      <div style={{ flex: 1, minWidth: 280 }}>
        {eyebrow && <div className="eyebrow">{Ic && <Ic />}{eyebrow}</div>}
        <h1>{title}</h1>
        {sub && <p className="sub">{sub}</p>}
      </div>
      {children && <div style={{ display: 'flex', gap: 10 }}>{children}</div>}
    </div>
  );
}

// Mandatory red AI validation note
function ValidationNote() {
  return (
    <div className="ai-validation">
      <Icon.shield className="ic" />
      <div className="t"><b>Validação pedagógica obrigatória.</b> {VALIDATION_NOTE}</div>
    </div>
  );
}

function BiasNote({ children }) {
  return (
    <div className="bias-note">
      <Icon.alert />
      <div>{children}</div>
    </div>
  );
}

// Minimal, safe markdown -> elements renderer (headings, bold, lists, hr, paragraphs)
function MD({ text }) {
  const lines = (text || '').split('\n');
  const blocks = [];
  let list = null, listType = null;
  const inline = (s) => {
    // escape then apply bold + inline code
    const parts = [];
    let rest = s;
    const re = /(\*\*[^*]+\*\*|`[^`]+`)/g;
    let last = 0, m;
    while ((m = re.exec(s))) {
      if (m.index > last) parts.push(s.slice(last, m.index));
      const tok = m[0];
      if (tok.startsWith('**')) parts.push(<strong key={parts.length}>{tok.slice(2, -2)}</strong>);
      else parts.push(<code key={parts.length}>{tok.slice(1, -1)}</code>);
      last = m.index + tok.length;
    }
    if (last < s.length) parts.push(s.slice(last));
    return parts;
  };
  const flush = () => {
    if (list) {
      const Tag = listType;
      blocks.push(<Tag key={blocks.length}>{list.map((li, i) => <li key={i}>{inline(li)}</li>)}</Tag>);
      list = null; listType = null;
    }
  };
  lines.forEach((raw) => {
    const line = raw.replace(/\s+$/, '');
    if (!line.trim()) { flush(); return; }
    let m;
    if ((m = line.match(/^#{1,4}\s+(.*)/))) { flush(); blocks.push(<h3 key={blocks.length}>{inline(m[1])}</h3>); return; }
    if (/^(-{3,}|\*{3,})$/.test(line.trim())) { flush(); blocks.push(<hr key={blocks.length} />); return; }
    if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { if (listType !== 'ul') { flush(); listType = 'ul'; list = []; } list.push(m[1]); return; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { if (listType !== 'ol') { flush(); listType = 'ol'; list = []; } list.push(m[1]); return; }
    flush();
    blocks.push(<p key={blocks.length}>{inline(line)}</p>);
  });
  flush();
  return <div className="md">{blocks}</div>;
}

function Thinking({ label = 'Prof. mAIcon está elaborando o conteúdo' }) {
  return (
    <div className="thinking">
      <div className="spinner green" />
      <span>{label}<span className="dots"><span>.</span><span>.</span><span>.</span></span></span>
    </div>
  );
}

// ============ AI engine ============
// Calls window.claude.complete with an engineered system prompt; falls back to a
// realistic local sample if the API is unavailable (so the banca demo never breaks).
async function runAI(systemPrompt, userPayload, fallback) {
  try {
    if (window.claude && typeof window.claude.complete === 'function') {
      const out = await window.claude.complete({
        messages: [
          { role: 'user', content: `${systemPrompt}\n\n=== PARÂMETROS SELECIONADOS PELO DOCENTE ===\n${userPayload}\n\nResponda em português do Brasil, em Markdown bem estruturado, pronto para uso em sala.` },
        ],
      });
      if (out && out.trim()) return out.trim();
    }
  } catch (e) { /* fall through to sample */ }
  await new Promise((r) => setTimeout(r, 1100));
  return fallback;
}

Object.assign(window, { Btn, Badge, Select, TextField, PageHead, ValidationNote, BiasNote, MD, Thinking, runAI });
